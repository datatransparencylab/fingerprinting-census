//Get website object with a certain url.

const config = {
   databaseURL: "https://privacymeter-eddbf.firebaseio.com/",
};

firebase.initializeApp(config);


var jsonObj = {};
var jsonRes = {};
const dbRef = firebase.database().ref('data/global/');
dbRef.on('value', snap => {
   jsonObj = snap.val();
   getGlobal(jsonObj);

});



function getGlobal(jsonObj) {
   jsonRes = jsonObj;
   var total_fingerprints = jsonRes.total_fingerprints;
   console.log(total_fingerprints);
   var total_sites = jsonRes.total_sites;
   console.log(total_sites);
};



